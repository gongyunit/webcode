// Iterator（遍历器）的概念
function iteratorFun() {
    var it = makeIterator(['a', 'b']);

   /* it.next() // { value: "a", done: false }
    it.next() // { value: "b", done: false }
    it.next() // { value: undefined, done: true }*/
    console.log(it.next());
    console.log(it.next());
    console.log(it.next());
}
function makeIterator(array) {
    var nextIndex = 0;
    return {
        next: function() {
            return nextIndex < array.length ?
                {value: array[nextIndex++], done: false} :
                {value: undefined, done: true};
        }
    };
}
// 数据结构的默认Iterator接口
function iteratorInterface(){
    let arr = ['a', 'b', 'c'];
    let iter = arr[Symbol.iterator]();

    iter.next() // { value: 'a', done: false }
    iter.next() // { value: 'b', done: false }
    iter.next() // { value: 'c', done: false }
    iter.next() // { value: undefined, done: true }
}
// 调用Iterator接口的场合
function iteratorFun1() {
    let set = new Set().add('a').add('b').add('c');

    let [x,y] = set;
    // x='a'; y='b'

    let [first, ...rest] = set;
    // first='a'; rest=['b','c'];

    // 例一
    var str = 'hello';
    [...str] //  ['h','e','l','l','o']

    // 例二
    let arr = ['b', 'c'];
    ['a', ...arr, 'd']
    // ['a', 'b', 'c', 'd']

    let generator = function* () {
        yield 1;
        yield* [2,3,4];
        yield 5;
    };

    var iterator = generator();

    iterator.next() // { value: 1, done: false }
    iterator.next() // { value: 2, done: false }
    iterator.next() // { value: 3, done: false }
    iterator.next() // { value: 4, done: false }
    iterator.next() // { value: 5, done: false }
    iterator.next() // { value: undefined, done: true }

}
// 字符串的Iterator接口
function iterator_str() {
    var someString = "hi";
    typeof someString[Symbol.iterator]
    // "function"

    var iterator = someString[Symbol.iterator]();

    iterator.next()  // { value: "h", done: false }
    iterator.next()  // { value: "i", done: false }
    iterator.next()  // { value: undefined, done: true }

}
// Iterator接口与Generator函数
function iterator_gen() {
    var myIterable = {};

    myIterable[Symbol.iterator] = function* () {
        yield 1;
        yield 2;
        yield 3;
    };
    [...myIterable] // [1, 2, 3]

// 或者采用下面的简洁写法

    let obj = {
        * [Symbol.iterator]() {
            yield 'hello';
            yield 'world';
        }
    };

    for (let x of obj) {
        console.log(x);
    }
    // hello
    // world
}
// 遍历器对象的return()，throw()
function readLinesSync(file) {
    return {
        next() {
            if (file.isAtEndOfFile()) {
                file.close();
                return { done: true };
            }
        },
        return() {
            file.close();
            return { done: true };
        },
    };
}
// for...of循环
function iterator_for() {
    const arr = ['red', 'green', 'blue'];

    for(let v of arr) {
        console.log(v); // red green blue
    }

    const obj = {};
    obj[Symbol.iterator] = arr[Symbol.iterator].bind(arr);

    for(let v of obj) {
        console.log(v); // red green blue
    }
}