

// Generator 基本用法
function* generFun() {
    yield '111';
    yield '2222';
    return 'ending';
}
function generConsole() {
    var text = generFun();
    console.log(text.next()); //{value: "111", done: false}
    console.log(text.next()); //{value: "2222", done: false}
    console.log(text.next()); //{value: "ending", done: true}
    console.log(text.next()); //{value: undefined, done: true}
}
function* f() {
    for(var i = 0; true; i++) {
        var reset = yield i;
        if(reset) { i = -1; }
    }
}
// next方法的参数
function generatorNext() {
    var g = f();
    g.next();// { value: 0, done: false }
    g.next(); // { value: 1, done: false }
    g.next(true); // { value: 0, done: false }
}
function* lodeUI(){
    showLoadingScreen();
    yield loadUIDataAsynchronously();
    hideLoadingScreen();
}

// 异步操作的应用
function generatoAsynFun() {
    var loader=loadUI();
    loader.next();
    loader.next();
}
function *foo() {
    yield 1;
    yield 2;
    yield 3;
    yield 4;
    yield 5;
    return 6;
}


// for…of
function forOfFun(){
    for (let v of foo()) {
        console.log(v);
    }
    // 1 2 3 4 5
}
function* yieldFoo() {
    yield 'a';
    yield 'b';
}
// Yield *语句
function yieldFun(){
    yield 'x';
    yield* yieldFoo();
    yield 'y';
}
