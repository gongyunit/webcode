
function indexOfFun() {
    var str='google';
    if(str.indexOf('o')>-1){
        document.getElementById("showDiv").innerHTML="str.indexOf('o')>-1=yes";
    }else{
        document.getElementById("showDiv").innerHTML="str.indexOf('o')>-1=no";
    }
}
// codePointAt()
function codePointAtFun() {
    var s = "𠮷";

    s.length // 2
    s.charAt(0) // "�"
    s.charAt(1) // "�"
    s.charCodeAt(0) // 55362
    s.charCodeAt(1) // 57271
    s.codePointAt(0) // 134071
    s.codePointAt(1) // 57271

    var s1 = "a";
    s1.length // 1
    s1.charAt(0) // 'a'
    s1.charCodeAt(0) // 55362
    s1.codePointAt(0) //
}
// String.fromCodePoint()
function fromCodePointFun() {
    var str=String.fromCodePoint(134071);
    console.log("str=",str);
    for (let codePoint of 'foo') {
        console.log(codePoint)
    }
    // "f"
    // "o"
    // "o"
    var text = String.fromCodePoint(0x20BB7);

    for (let i = 0; i < text.length; i++) {
        console.log(text[i]);
    }
    // " "
    // " "
    for (let i of text) {
        console.log(i);
    }
    // "𠮷"
}
// 字符串Unicode 表示法
function unicodeFun() {
    /*"\u0061" //"a"
    "\uD842\uDFB7"
    // "𠮷"
        "\u20BB7"
    // " 7"*/
    console.log("\u20BB7");
}
// 正则表达式的额u修饰符
function stringU() {
    var s= "𠮷";
   // /^.$/.test(s)
    console.log(/^.$/.test(s));
    console.log(/^.$/u.test(s));
}
// includes(), startsWith(), endsWith()
function includeFun() {
    //contains
    let str='google';
    if(str.includes('o')){
        document.getElementById("showDiv").innerHTML="str.includes('o')======yes";
    }else{
        document.getElementById("showDiv").innerHTML="str.includes('o')======no";
    }
}
function startsWithFun() {
    let str='google';
    var start=str.startsWith('g');
    var end=str.endsWith('e');
    document.getElementById("showDiv").innerHTML="str.startsWith('g')==="+start+";str.endsWith('e')=="+end;
}
// repeat()
function repeatFun() {
    let str = 'google';
    console.log(str.repeat(3)); //googlegooglegoogle
    document.getElementById("showDiv").innerHTML="str.repeat(3)==="+str.repeat(3)+";str.repeat(3.5)=="+str.repeat(Math.floor(3.5));
}
// 正则表达式的y修饰符
function stringY() {
    var str="aaa_aa_a";
    var r1=/a+/g;
    var r2=/a+/y;
    r1.exec(str);//["aaa"]
    r2.exec(str);//["aaa"]

    r1.exec(str);//["aaa"]
    r2.exec(str);//null


}
// 模板字符串
function template() {
   console.log("单行",`hello world`);
   console.log("多行",`hello 
    world`);
   var name="jack",age='16';
    console.log("带参数",`${name},is ${age} year old`);
}


//es7
function padFun() {
    let str='goo';
    var start=str.padStart(5, 'le');
    var end=str.padEnd(4, 'le');
    document.getElementById("showDiv").innerHTML="str.padStart(5, 'le');==="+start+";str.padEnd(4, 'le')"+end;
}
