// 基本用法
function basicFun() {
    var promise = new Promise(function(resolve, reject) {
        // ... some code

        if (true){/* 异步操作成功 */
            resolve(value);
        } else {
            reject(error);
        }
    });
}
// 链式操作 then方法
function promiseThen(num) {
    return new Promise(function (resolve,reject) {
        if (typeof num == 'number') {
            resolve();
        } else {
            reject();
        }
    }).then(function () {
        console.log("yes");
    },function () {
        console.log("no");
    })
}
// Catch 方法：捕捉错误
function promiseCatch(num) {
    // 写法一
    var promise = new Promise(function(resolve, reject) {
        try {
            throw new Error('test');
        } catch(e) {
            reject(e);
        }
    });
    promise.catch(function(error) {
        console.log(error);
    });

// 写法二
    var promise = new Promise(function(resolve, reject) {
        reject(new Error('test'));
    });
    promise.catch(function(error) {
        console.log(error);
    });
}
// Promise.all()
function promiseAll() {
    var promises = [2, 3, 5, 7, 11, 13].map(function (id) {
        return getJSON("/post/" + id + ".json");
    });

    Promise.all(promises).then(function (posts) {
        // ...
    }).catch(function(reason){
        // ...
    });
}
// Promise.resolve()
function promiseResolve() {
    let thenable = {
        then: function(resolve, reject) {
            resolve(42);
        }
    };

    let p1 = Promise.resolve(thenable);
    p1.then(function(value) {
        console.log(value);  // 42
    });

}
// async 函数
async function promiseAsync(symbol,currency) {
        let price=await getStockPrice(symbol);
        return convert(price,currency)
}
