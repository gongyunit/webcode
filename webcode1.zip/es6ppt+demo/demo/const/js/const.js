const PI = 3.1415;
PI // 3.1415

//PI = 3;//Assignment to constant variable.

//const foo; //错误写法 需要立即初始化