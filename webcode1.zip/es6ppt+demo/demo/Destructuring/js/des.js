
//变量赋值
function fun1() {
    let a = 1;
    let b = 2;
    let c = 3;
    document.getElementById("showDiv").innerHTML="a="+a+";b="+b+";c="+c;
}
function fun2(){
    let a =1,b=2,c=3;
    document.getElementById("showDiv").innerHTML="a"+a+";b="+b+";c="+c;
}

//嵌套数组解构
function fun3() {
    let [foo,[[bar],baz]]=[1,[[2],3]];
    document.getElementById("showDiv").innerHTML="foo="+foo+";bar="+bar+";baz="+baz;
    //foo //1
    // bar 2
    //baz 3

}
function fun4() {
    let [,,third]=["foo","bar","baz"];
    document.getElementById("showDiv").innerHTML="third="+third;
    //third baz
}

function fun5() {
    let[x,,y]=[1,2,3];
    document.getElementById("showDiv").innerHTML="x="+x+";y="+y;
    //x 1
    //y 3
}
function fun6() {
    let [head, ...tail]=[1,2,3,4];
    document.getElementById("showDiv").innerHTML="head="+head+";tail="+tail;
    //head 1
    //tail [2,3,4]
}
function fun7() {
    let [x,y,...z] =["a"];
    document.getElementById("showDiv").innerHTML="x="+x+";y="+y+";z="+z;
    //x a
    //y undefined
    //z []
}
//解构不成功
function fun8() {
    let [foo] = [];
    document.getElementById("showDiv").innerHTML="foo="+foo;
    //foo undefined
}
function fun9() {
    let [bar, foo] = [1];
    document.getElementById("showDiv").innerHTML="bar="+bar+";foo="+foo;
    //foo undefined
}
//有剩余属于不完全解构
function fun10() {
    let [x, y] = [1, 2, 3];
    document.getElementById("showDiv").innerHTML="x="+x+";y="+y;
    x // 1
    y // 2
}
function fun11() {
    let [a, [b], d] = [1, [2, 3], 4];
    document.getElementById("showDiv").innerHTML="a="+a+";b="+b+";d="+d;
    a // 1
    b // 2
    d // 4
}

//等号的右边不是数组（或者严格地说，不是可遍历的结构），那么将会报错。
// 报错
function fun12() {
    let [foo] = 1;
    document.getElementById("showDiv").innerHTML="foo="+foo;
}

function fun13() {
    let [foo] = false;
    document.getElementById("showDiv").innerHTML="foo="+foo;
}
function fun14() {
    let [foo] = NaN;
    document.getElementById("showDiv").innerHTML="foo="+foo;
}

function fun15() {
    let [foo] = undefined;
    document.getElementById("showDiv").innerHTML="foo="+foo;
}
function fun16() {
    let [foo] = null;
    document.getElementById("showDiv").innerHTML="foo="+foo;
}
function fun17() {
    let [foo] = {};
    document.getElementById("showDiv").innerHTML="foo="+foo;
}

//对于 Set 结构，也可以使用数组的解构赋值。
function fun18() {
    let [x, y, z] = new Set(['a', 'b', 'c']);

    x // "a"
    y // "b"
    z // "c"
}

//Generator函数
function* fibs() {
    let a = 0;
    let b = 1;
    while (true) {
        yield a;
        [a, b] = [b, a + b];
    }
}
function fun19() {
    let [first, second, third, fourth, fifth, sixth] = fibs();
    document.getElementById("showDiv").innerHTML="first="+first+";second="+second+";third="+third+";fourth="+fourth+";fifth="+fifth+";sixth="+sixth;
    //first 0
    //second 1
    //third 1
    //fourth 2
    //fifth 3
    //sixth 5
}
//解构赋值允许指定默认值。
function fun20() {
    let [foo = true] = [];
    document.getElementById("showDiv").innerHTML="foo="+foo;
    foo // true
}
function fun21() {
    let [x, y = 'b'] = ['a']; // x='a', y='b'
    document.getElementById("showDiv").innerHTML="x="+x+";y="+y;
}
function fun22() {
    let [x, y = 'b'] = ['a', undefined]; // x='a', y='b'
    document.getElementById("showDiv").innerHTML="x="+x+";y="+y;
}
function fun23() {
    let [x = 1] = [undefined];
    document.getElementById("showDiv").innerHTML="x="+x;
    x // 1
}
function fun24() {
    let [x = 1] = [null];
    document.getElementById("showDiv").innerHTML="x="+x;
    x // null
}
function f() {
    console.log('aaa');
}
//表达式是惰性求值
function fun25() {
    let [x = f()] = [1];
    document.getElementById("showDiv").innerHTML="x="+x;

   /* let x;
    if ([1][0] === undefined) {
        x = f();
    } else {
        x = [1][0];
    }*/
}
//字符串解构
function fun26() {
    const [a, b, c, d, e] = 'hello';
    document.getElementById("showDiv").innerHTML="a="+a+";b="+b+";c="+c+";d="+d+";e="+e;
  /*  a // "h"
    b // "e"
    c // "l"
    d // "l"
    e // "o"*/
}
function fun27() {
    let {length : len} = 'hello';
    document.getElementById("showDiv").innerHTML="len="+len;
    // len // 5
}
//对象解构
function fun28(){
    let { foo, bar } = { foo: "aaa", bar: "bbb" };
    document.getElementById("showDiv").innerHTML="foo="+foo+";bar="+bar;
    // foo // "aaa"
    // bar // "bbb"
}
//布尔值解构
function fun29() {
    let {toString: s} = 123;
    var boolData=s === Number.prototype.toString;
    document.getElementById("showDiv").innerHTML="s === Number.prototype.toString ="+boolData;
    // true
}
function fun30() {
    let {toString: s} = true;
    var boolData=Boolean.prototype.toString;
    document.getElementById("showDiv").innerHTML="s === Boolean.prototype.toString ="+boolData;
    //s === Boolean.prototype.toString // true
}
function fun31(){
    function add([x, y]){
        return x + y;
    }
    // add([1, 2]); // 3
    document.getElementById("showDiv").innerHTML="add([1, 2]) ="+add([1, 2]);
}






