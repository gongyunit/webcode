//二进制和八进制表示法
function fun1() {
   // 0b111110111 === 503 // true
    //0o767 === 503 // true
   /* Number('0b111')//7
    Number('0o10')  // 8*/
   var obdata=Number('0b111');
   var oodata=Number('0o10');

   document.getElementById("showDiv").innerHTML="Number('0b111')=="+obdata+"Number('0o10')"+oodata;
}
//Number.isFinite(), Number.isNaN()
function fun2() {
    // Number.isFinite(15); // true
    // Number.isFinite(NaN); // false
    // Number.isNaN(NaN) // true
    // Number.isNaN(15) // false
    var isFin= Number.isFinite(15);
    var isnan=Number.isNaN(15);
    document.getElementById("showDiv").innerHTML="Number.isFinite(NaN)=="+isFin+"Number.isNaN(15)"+isnan;
}

// Number.parseInt(), Number.parseFloat()
function fun3() {
    // ES5的写法
    // parseInt('12.34') // 12
    // parseFloat('123.45#') // 123.45

    // ES6的写法
    // Number.parseInt('12.34') // 12
    // Number.parseFloat('123.45#') // 123.45
    var intData=Number.parseInt('12.34');
    var floatData=Number.parseFloat('123.45#');
    document.getElementById("showDiv").innerHTML="Number.parseInt('12.34')=="+intData+"Number.parseFloat('123.45#')"+floatData;
}
// Number.isInteger()
function fun4() {
   /* Number.isInteger(25) // true
    Number.isInteger(25.0) // true
    Number.isInteger(25.1) // false*/
   var d1=Number.isInteger(25);
   var d2=Number.isInteger(25.0);
   var d3=Number.isInteger(25.1);
    document.getElementById("showDiv").innerHTML="Number.isInteger(25)=="+d1+"Number.isInteger(25.0)"+d2+"Number.isInteger(25.1)"+d3;
}
// Number.EPSILON
function fun5() {
    //Number.EPSILON
    document.getElementById("showDiv").innerHTML="Number.EPSILON=="+Number.EPSILON;
}
// 安全整数和Number.isSafeInteger()
// Math对象的扩展
// Math.signbit()
// 指数运算符
function fun6() {
    2 ** 3 // 8
    let b = 4;
    b **= 3;  //64
    document.getElementById("showDiv").innerHTML="2 ** 3 =="+2 ** 3 +";let b = 4;b **= 3;=="+b;
}