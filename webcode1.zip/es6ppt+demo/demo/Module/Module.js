export var firstName = 'Michael';
export var lastName = 'Jackson';
export var year = 1958;

var firstName = 'Michael';
var lastName = 'Jackson';
var year = 1958;

//变量导出
export {firstName, lastName, year};

//函数导出
function v1() { }
function v2() { }

export {
    v1 as streamV1,
    v2 as streamV2,
    v2 as streamLatestVersion
};


export default function () {
    console.log('foo');
}

//模块的整体加载
export function area(radius) {
  return Math.PI * radius * radius;
}

export function circumference(radius) {
  return 2 * Math.PI * radius;
}


//emport default
export default function () {
  console.log('foo');
}

//模块的继承
export * from 'circle';
export var e = 2.71828182846;
export default function(x) {
  return Math.exp(x);
}


export { area as circleArea } from 'circle';

