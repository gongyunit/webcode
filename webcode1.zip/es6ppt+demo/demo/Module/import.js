/**
 * Created by wlj on 2017/4/12.
 */
import {name} from "./Module";
console.log(name);


//导入变量
import {firstName, lastName, year} from './Module';

function setName(element) {
    element.textContent = firstName + ' ' + lastName;
}


//default e
import customName from './Module';
customName(); // 'foo'

//模块的整体加载
//
import { area, circumference } from './Module';

console.log('圆面积：' + area(4));
console.log('圆周长：' + circumference(14));

import * as circle from './Module';

console.log('圆面积：' + circle.area(4));
console.log('圆周长：' + circle.circumference(14));


//emport default
import customName from './export-default';
customName(); // 'foo'

//模块的继承
//
import * as math from 'circleplus';
import exp from 'circleplus';
console.log(exp(math.e));
export * from 'circle';
export var e = 2.71828182846;
export default function(x) {
  return Math.exp(x);
}


export { area as circleArea } from 'circle';