// Set
function setFun() {
    var set = new Set([1, 2, 3, 4, 4]);
    [...set]
    // [1, 2, 3, 4]
    var s=new Set();
    s.add(1).add(2).add(2);
    // 注意2被加入了两次

    s.size // 2

    s.has(1) // true
    s.has(2) // true
    s.has(3) // false

    s.delete(2);
    s.has(2) // false
    document.getElementById("answerShow").innerHTML="var set = new Set([1, 2, 3, 4, 4]); [...set]="+set;
}
// WeakSet
function weekSetFun() {
    var a = [[1,2], [3,4]];
    var ws = new WeakSet(a);
    document.getElementById("answerShow").innerHTML="var a = [[1,2], [3,4]];var ws = new WeakSet(a);="+ws;

}
// Map
function mapFun() {
    var m = new Map();
    var o = {p: 'Hello World'};

    m.set(o, 'content')
    m.get(o) // "content"
    document.getElementById("answerShow").innerHTML=" var m = new Map();var o = {p: 'Hello World'};m.set(o, 'content')m.get(o) ="+m.get(o);

    m.has(o) // true
    m.delete(o) // true
    m.has(o) // false

    var map = new Map([
        ['name', '张三'],
        ['title', 'Author']
    ]);

    map.size // 2
    map.has('name') // true
    map.get('name') // "张三"
    map.has('title') // true
    map.get('title') // "Author"

}
// WeakMap
function weakMapFun() {
    var map = new WeakMap();
    map.set({"key":1},1);
    //map.set(1, 2)
    // TypeError: 1 is not an object!
    // map.set(Symbol(), 2)
    document.getElementById("answerShow").innerHTML="var map = new WeakMap();map.set({'key':1},1);="+map;
}