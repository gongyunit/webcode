// Array.from()
function arrayFrom() {
    let arrayLike = {
        '0': 'a',
        '1': 'b',
        '2': 'c',
        length: 3
    };

    // ES5的写法
        var arr1 = [].slice.call(arrayLike); // ['a', 'b', 'c']

    // ES6的写法
        let arr2 = Array.from(arrayLike); // ['a', 'b', 'c']

    document.getElementById("showDiv").innerHTML="let arrayLike = {'0': 'a','1': 'b','2': 'c',length: 3};=="+arr2;
}
// Array.of()
function arrayOf() {
      var newArray= Array.of(1,2,3);
    document.getElementById("showDiv").innerHTML="Array.of(1,2,3)=="+newArray;
}
// 数组实例的copyWithin()
function conpyWithin() {
    // Array.prototype.copyWithin(target, start = 0, end = this.length)
    var array=[1, 2, 3, 4, 5].copyWithin(0, 3);
    document.getElementById("showDiv").innerHTML="[1, 2, 3, 4, 5].copyWithin(0, 3)=="+array;

}
// 数组实例的find()和findIndex()
function findIndex(){
   var findData= [1, 4, -5, 10].find((n) => n < 0);
   var findIdex= [1, 5, 10, 15].findIndex(function(value, index, arr) {
        return value > 9;
    });
    document.getElementById("showDiv").innerHTML="[1, 4, -5, 10].find((n) => n < 0)=="+findData+";[1, 5, 10, 15].findIndex=="+findIdex;
}
// 数组实例的fill()
function fillFun(){
   var fillArr1 = ['a', 'b', 'c'].fill(7);  // [7, 7, 7]
   var fillArr2=new Array(3).fill(7); // [7, 7, 7]
   var fillArr3= ['a', 'b', 'c'].fill(7, 1, 2); //// ['a', 7, 'c']
    document.getElementById("showDiv").innerHTML="['a', 'b', 'c'].fill(7)=="+fillArr1+";new Array(3).fill(7);=="+fillArr2+";['a', 'b', 'c'].fill(7, 1, 2)==="+fillArr3;


}
// 数组实例的entries()，keys()和values()
function entriesFun() {
    for (let index of ['a', 'b'].keys()) {
        console.log(index);
    }
// 0
// 1

    for (let elem of ['a', 'b'].values()) {
        console.log(elem);
    }
// 'a'
// 'b'

    for (let [index, elem] of ['a', 'b'].entries()) {
        console.log(index, elem);
    }
// 0 "a"
// 1 "b"
}
// 数组实例的includes()
function includes() {
   var includeTrue= [1, 2, 3].includes(2);     // true
   var includefalse=[1, 2, 3].includes(4);     // false
   var include2= [1, 2, 3].includes(3, 3);  // false  第二个参数为从第几个位置开始查找 可以为负数
    document.getElementById("showDiv").innerHTML="[1, 2, 3].includes(2)=="+includeTrue+";[1, 2, 3].includes(4)=="+includefalse+";[1, 2, 3].includes(3, 3)==="+include2;

}
// 数组的空位
function arrayEmpty() {
  var arr1=  Array(3) // [, , ,]
  var arr2=Array.from(['a',,'b'])// [ "a", undefined, "b" ]
  var arr3= [...['a',,'b']]// [ "a", undefined, "b" ]
  document.getElementById("showDiv").innerHTML="Array(3)=="+arr1+";Array.from(['a',,'b'])=="+arr2+";[...['a',,'b']]==="+arr3;

}
