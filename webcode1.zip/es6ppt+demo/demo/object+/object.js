// 属性的简洁表示法
function varObj() {
    var foo = 'bar';
    var baz = {foo};//es6
    baz // {foo: "bar"}
    var baz = {foo: foo};//es5

    //es5
    function fooFun(x, y) {
        return {x, y};
    }

    // 等同于
    //es5
   /* function fooFun(x, y) {
        return {x: x, y: y};
    }
    */
    f(1, 2) // Object {x: 1, y: 2}

    var o = {
        method() {
            return "Hello!";
        }
    };

    // 等同于
    //es5
    /*var o = {
        method: function() {
            return "Hello!";
        }
    };*/

}
// 属性名表达式
function Expression() {
    // 方法一
    obj.foo = true;

    // 方法二
    obj['a' + 'bc'] = 123;

    let propKey = 'foo';

    let obj = {
        [propKey]: true,
        ['a' + 'bc']: 123
    };
    
}
//方法的 name 属性
function methodName() {
    const person = {
        sayName() {
            console.log('hello!');
        },
    };

    person.sayName.name   // "sayName"

    const obj = {
        get foo() {},
        set foo(x) {}
    };

    obj.foo.name
// TypeError: Cannot read property 'name' of undefined


    const key1 = Symbol('description');
    const key2 = Symbol();
    let obj = {
        [key1]() {},
        [key2]() {},
    };
    obj[key1].name // "[description]"
    obj[key2].name // ""

}


// Object.is()
function objectIs() {
    Object.is('foo', 'foo')
    // true
    Object.is({}, {})
    // false

    +0 === -0 //true
    NaN === NaN // false

    Object.is(+0, -0) // false
    Object.is(NaN, NaN) // true
}
// Object.assign()
function obj_assign() {
    var target = { a: 1 };

    var source1 = { b: 2 };
    var source2 = { c: 3 };

    Object.assign(target, source1, source2);

  //  target//{a:1, b:2, c:3}
   // source1 { b: 2 }
    //source2 { c: 3 }

}
// 属性的可枚举性
function objEnum() {
    let obj = { foo: 123 };
    Object.getOwnPropertyDescriptor(obj, 'foo')
    
}
// 属性的遍历
function forEunm() {
    Reflect.ownKeys({ [Symbol()]:0, b:0, 10:0, 2:0, a:0 })

}
// __proto__属性，Object.setPrototypeOf()，Object.getPrototypeOf()
function proto() {
    // es6的写法
    var obj = {
        method: function() {  }
    };
    obj.__proto__ = someOtherObj;

// es5的写法
    var obj = Object.create(someOtherObj);
    obj.method = function() {  };


    // 格式
    Object.setPrototypeOf(obj, prototype)
    Object.getPrototypeOf(obj);

    // 用法
    var o = Object.setPrototypeOf({}, null);
}
// Object.keys()，Object.values()，Object.entries()
function getkeys() {
    //Object.keys()
    var obj = { foo: 'bar', baz: 42 };
    Object.keys(obj)
    // ["foo", "baz"]

    //Object.values()
    var obj1= { foo: 'bar', baz: 42 };
    Object.values(obj1)
    // ["bar", 42]

    //Object.entries()
    var obj = { foo: 'bar', baz: 42 };
    Object.entries(obj)
    // [ ["foo", "bar"], ["baz", 42] ]
}
// 对象的扩展运算符
function objOperation() {
    const [a, ...b] = [1, 2, 3];
    a // 1
    b // [2, 3]
}
// Object.getOwnPropertyDescriptors()
function getProper() {
    var obj = { p: 'a' };

    Object.getOwnPropertyDescriptor(obj, 'p')
    // Object { value: "a",
    //   writable: true,
    //   enumerable: true,
    //   configurable: true
    // }

}
