import list from './mock/list';

export default {
  'GET /api/list': list.list
};
