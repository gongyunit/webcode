import React from 'react';
import ReactDOM from 'react-dom';
import HelloWorld from './component/HelloWorld';
import './index.css';

ReactDOM.render(
  <HelloWorld name="test" />,
  document.getElementById('root')
);
