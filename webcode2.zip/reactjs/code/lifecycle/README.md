# React生命周期

> 运行前需要安装node_modules，npm install

运行 开发模式
### `npm start`
运行 自动化测试
### `npm test`
运行 打包编译部署
### `npm run build`
运行 代码检查
### `npm run eject`
